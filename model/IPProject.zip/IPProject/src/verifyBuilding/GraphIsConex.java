package verifyBuilding;

public class GraphIsConex {

}
