package buildingCreator;
import java.util.HashMap;
import java.util.Map;

import org.javatuples.Pair;

import buildingInfo.Building;
import buildingInfo.Corner;
import buildingInfo.Door;
import buildingInfo.Equipment;
import buildingInfo.Level;
import buildingInfo.Room;
import buildingInfo.Vertices;
import buildingInfo.Wall;
import buildingInfo.Window;

public class levelGraph {
	
	public static HashMap<Vertices,Pair<Room,Room>> House = new HashMap<Vertices,Pair<Room,Room>>(200);	 

	public static void main(String[] args) throws NullPointerException {   	

		buildingInfo.Building myBuilding = new Building("House", 7.0, 7.5, 10.6);
		myBuilding.setLevelNumber(2);
		
		buildingInfo.Level levelOne = new Level(1);
		myBuilding.addLevel(levelOne);
		
		buildingInfo.Room roomOne = new Room(1,"Room", 2.0, 3.0, 4.0);
		levelOne.Rooms.add(roomOne);
		buildingInfo.Room roomTwo = new Room(2,"Hallway",2.0, 3.0, 6.0);
		levelOne.Rooms.add(roomTwo);
		
		buildingInfo.Vertices v1 = new Vertices(1,2);
	
		buildingInfo.Wall wallOne = new Wall(1, 0.2, 4.0);
		buildingInfo.Wall wallTwo = new Wall(2, 0.2, 3.0);
		roomOne.addWall(wallOne);
		roomOne.addWall(wallTwo);

		buildingInfo.Equipment equipmentOne = new Equipment(1,0,false,10.0,5.0);
		equipmentOne.placeEquipment(roomOne);		
		
		buildingInfo.Window windowOne = new Window(1, 0.2, 0.2);
		windowOne.setPositions(2.0, 3.0);
		wallOne.addWindow(windowOne);
		
		buildingInfo.Door doorOne = new Door(1,"Internal", 0.2, 0.4);
		wallOne.addDoor(doorOne);
		
		buildingInfo.Corner cornerOne = new Corner();
		cornerOne.setPositions(3, 4);
		cornerOne.addWall(wallOne);
		cornerOne.addWall(wallTwo);

		House.put(v1, Pair.with(roomOne, roomTwo));
		

		//DE MUTAT IN DISPLAY
		for (Map.Entry<Vertices,Pair<Room,Room>> entry: House.entrySet())
		{
			Vertices key = entry.getKey();
			Pair<Room, Room> value = entry.getValue();

			System.out.println(key.firstLabel + " " + key.secondLabel);
			String segments[] = value.getValue(0).toString().split(" ");
			System.out.println(segments[0] + " " + segments[1]);

			String segments2[] = value.getValue(1).toString().split(" ");
			System.out.println(segments2[0] + " " + segments2[1]);
			
		}
	}
}
