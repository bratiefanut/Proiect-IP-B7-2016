package displayInfo;

public class displayBuilding {

}
