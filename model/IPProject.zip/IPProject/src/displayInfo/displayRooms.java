package displayInfo;

public class displayRooms {

}
