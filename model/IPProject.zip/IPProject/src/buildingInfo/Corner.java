package buildingInfo;

import java.util.Vector;

public class Corner {

	public Vector<Integer> wallLabels = new Vector<Integer>(20);
	public Integer x;
	public Integer y;

	public void addWall(Wall w){
		if (wallLabels.contains(w.label)) 
			System.out.println("Wall is already contained by the corner.");
		else 
			wallLabels.addElement(w.label);		
	}
	
	public void setPositions(Integer x, Integer y) {
		this.x = x;
		this.y = y;
	}
}