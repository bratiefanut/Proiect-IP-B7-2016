package buildingInfo;

import java.util.Vector;

public class Building {

	public Integer levelNumber;
	public Double width;
	public Double length;
	public Double heigth;
	public String Name;
	public Vector<Level> Levels = new Vector<Level>(20);

	// public Vector  myLevel;
	// public Vector  myLevel;
	// public Vector  myRoom;

	
	public Building(String Name, Double heigth, Double width, Double length) {		
		this.heigth = heigth;
		this.width = width;
		this.length = length;
		this.Name = Name;
	}

	public void eraseBuilding() {		
		this.heigth = 0.0;
		this.width = 0.0;
		this.length = 0.0;
		this.Name = "";
	}
	
	public void addLevel(Level L) {
		if (Levels.contains(L)) 
			System.out.println("Level is already registered!");
		else Levels.add(L);
	}

	public Double getWidth() {
		return width;
	}

	public void setWidth(Double width) {
		this.width = width;
	}

	public Double getLength() {
		return length;
	}

	public void setLength(Double length) {
		this.length = length;
	}

	public Double getHeight() {
		return heigth;
	}

	public void setHeight(Double height) {
		this.heigth = height;
	}

	public Integer getLevelNumber() {
		return levelNumber;
	}

	public void setLevelNumber(Integer levelNumber) {
		this.levelNumber = levelNumber;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

}