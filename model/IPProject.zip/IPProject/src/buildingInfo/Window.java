package buildingInfo;

public class Window {

	public Double width;
	public Double  height;
	public Integer windowLabel;
	public Double x;
	public Double y;
	
	
	public Window(Integer windowLabel, Double width, Double height){
		
		this.windowLabel = windowLabel;
		this.width = width;
		this.height = height;
	}

	public void setPositions(Double x, Double y){
		this.x = x;
		this.y = y;
	}


}