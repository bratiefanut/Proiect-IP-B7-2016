package buildingInfo;

import java.util.Vector;

public class Wall {

	public Double width;
	public Double height;
	public Integer label;
	public Vector<Integer> windows = new Vector<Integer>(20);
	public Vector<Integer> doors = new Vector<Integer>(20);
	
	public Wall (Integer label ,Double width, Double height){
		this.label = label;
		this.width = width;
		this.height = height;
	}
	
	public void addWindow(Window w){
		windows.addElement(w.windowLabel);
	}
	
	public void deleteWindow(Integer label){		
		if(windows.contains(label)){
			windows.remove(label);
		} else {
			System.out.println("Window does not exist!");
		}
	}
	
	public void addDoor(Door d){
		doors.addElement(d.doorLabel);
	}
	
	public void deleteDoor(Integer label){
		if(doors.contains(label))
			doors.remove(label);
		else
			System.out.println("Door does not exist!");
			
	}

}