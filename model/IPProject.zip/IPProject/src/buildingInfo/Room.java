package buildingInfo;

import java.util.Vector;

public class Room {

	public Double width;
	public Double height;
	public Double length;
	public Double capacity;
	public Integer doorNumber;
	public Integer label;
	public String type;
	
	@Override
	public String toString() {
		return (label + " " + type);
	}
	
	public Vector<Integer> walls = new Vector<Integer>();
	
	public Room (Integer label, String type, Double width, Double heigth, Double length){
		this.label = label;
		this.type = type;
		this.width = width; 
		this.height = heigth;
		this.length = length;
	}
	
	public void addWall(Wall w){
		walls.addElement(w.label);
	}
	
	public void deleteWall(Integer label){
		if(walls.contains(label))
			walls.remove(label);
		else {
			System.out.println("Wall does not exist!");
		}
	}
	

}