package buildingInfo;

public class Vertices {

  public Integer firstLabel;
  public Integer secondLabel;
  public Vertices(Integer f, Integer s) {
	  this.firstLabel = f;
	  this.secondLabel = s;
  }

}