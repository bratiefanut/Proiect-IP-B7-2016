package buildingInfo;

public class Door {

	public String type;
	public Integer capacity;
	public Double x;
	public Double y;
	public Boolean isHermetic;
	public Double width;
	public Double heigth;
	public Integer doorLabel;

	public Door (Integer doorLabel, String type, Double width, Double heigth){
		this.doorLabel = doorLabel;
		this.type = type;
		this.width = width;
		this.heigth = heigth;
	}

	public void setPositions(Double x, Double y){
		this.x = x;
		this.y = y;
	}
	
	

}