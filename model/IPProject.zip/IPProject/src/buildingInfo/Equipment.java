package buildingInfo;

public class Equipment {
	public Integer extuinguisherNumber;
	public Integer sprinklerNumber;
	public Boolean smokeDetector;
	public Double extuinguisherX;
	public Double extuinguisherY;	
	public Integer roomLabel;
	
	public Equipment (Integer extNo, Integer sprinklerNo, Boolean smokeDet, Double extX, Double extY) {
		this.extuinguisherNumber = extNo;
		this.sprinklerNumber = sprinklerNo;
		this.smokeDetector = smokeDet;
		this.extuinguisherX = extX;
		this.extuinguisherY = extY;
	}
	
	public void placeEquipment(Room R) {
		this.roomLabel = R.label;
	}
}