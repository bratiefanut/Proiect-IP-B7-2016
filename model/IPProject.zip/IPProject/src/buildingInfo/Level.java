package buildingInfo;

import java.util.Vector;

public class Level {

	public Integer levelNumber;
	public Integer roomNumber;
	public Vector<Room> Rooms = new Vector<Room>(20);
	
	public Level (Integer lNumber) {
		this.levelNumber = lNumber;
	}	

	public void setLevelNumber(Integer number) {
		this.levelNumber = number;
	}

	public void setRoomNumber(Integer number) {
		this.roomNumber = number;
	}


}