package configuration;

import java.io.FileInputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.NodeList;

public class XmlParser {
	public static void main(String[] args) throws NullPointerException {  
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		try {
			// use the factory to create a documentbuilder
			DocumentBuilder builder = factory.newDocumentBuilder();
			// create a new document from input stream
			FileInputStream fis = new FileInputStream("C:\\Users\\BeatriceGhetel\\workspace\\IPProject\\src\\configuration\\Configure.xml");
			org.w3c.dom.Document doc = builder.parse(fis);
			// get the first element
			org.w3c.dom.Element element = doc.getDocumentElement();
			// get all child nodes
			NodeList nodes = element.getChildNodes();
			// print the text content of each child
			for (int i = 0; i < nodes.getLength(); i++) {
				System.out.println("" + nodes.item(i).getTextContent());
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
