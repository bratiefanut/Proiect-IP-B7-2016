package buildingInfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "WINDOW")
@XmlAccessorType(XmlAccessType.FIELD)
public class Window {
	@XmlElement(name="width")
    private String width;

    @XmlElement(name="height")
    private String height;

    @XmlElement(name="windowX")
    private String windowX;
    
    @XmlElement(name="windowY")
    private String windowY;
    
    @XmlElement(name="wallLabel")
    private String wallLabel;

    @XmlElement(name="WindowID")
    private String windowID;
    
	@Override
	public String toString() {
		return "Window [windowID=" + windowID + ", width=" + width + ", height=" + height + ", windowX=" + windowX + ", windowY=" + windowY
				+ ", wallLabel=" + wallLabel + "]";
	}
    
}
