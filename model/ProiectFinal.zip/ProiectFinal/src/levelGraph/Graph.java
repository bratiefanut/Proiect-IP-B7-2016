package levelGraph;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import buildingInfo.Building;
import buildingInfo.Door;
import buildingInfo.Level;
import buildingInfo.Room;

public class Graph {
	public static boolean checkDoors(String roomLabel1, String roomLabel2, Level[] L) throws JAXBException {
		if (roomLabel1.equalsIgnoreCase(roomLabel2)) return false;
		String found1 = new String("");
		String found2 = new String("");
		for (Level level : L) {
			Room[] R = level.getRoom();
			for (Room room : R) {				
				Door[] D = room.getDoors();
				for (Door door : D) {
					if (roomLabel1.equalsIgnoreCase(room.getLabel())) found1 = door.getId();
					if (roomLabel2.equalsIgnoreCase(room.getLabel())) found2 = door.getId();					
					if (found1.equalsIgnoreCase(found2)) return true;					
				
					System.out.println("Nivel: " + level.getLevelNumber() + "Camera: " + room.getLabel() + room.getType() + "Usa: " + door.getId());
				}
			}			
		}		
		return false;
	}

	public static Integer[][] generateAdjanceyMatrix(Level L, Level[] l) throws JAXBException {
		int roomNumber = Integer.parseInt(L.getRoomNumber());	
		Integer[][] matrix = new Integer[roomNumber+1][roomNumber+1];
		for (int i = 1; i<=roomNumber; i++) {
			for (int j = 1; j<=roomNumber; j++) {
				if ((checkDoors(Integer.toString(i),Integer.toString(j),l)))
					matrix[i][j]=1;
				else
					matrix[i][j]=0;
			}
		}

		return matrix;
	}

	public static  void showMatrix(Integer[][] M) {		
		for(int i = 1; i<M.length; i++)	{
			for(int j=1; j<M.length;j++)
				System.out.print(M[i][j] + " ");
			System.out.println();
		}		
	}

	public static void main(String[] args) throws JAXBException {
		File file = new File("src\\parserXML\\Base.xml");
		JAXBContext jaxbContext = JAXBContext.newInstance(Building.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		Building build = (Building) jaxbUnmarshaller.unmarshal(file);
		System.out.println(build);
		Level[] L = build.getLevels();
		for (Level levels : L) {
			int roomNumber = Integer.parseInt(levels.getRoomNumber());	
			System.out.println(roomNumber);
			
			int levelNumber = Integer.parseInt(levels.getLevelNumber());
			System.out.println(levelNumber);
			Integer[][] m = new Integer[roomNumber+1][roomNumber+1];
			m = generateAdjanceyMatrix(levels, L);
			System.out.println("Matrice pe nivelul " + levelNumber);
			showMatrix(m);
			
			System.out.println();
			
		}
	
	}
}

