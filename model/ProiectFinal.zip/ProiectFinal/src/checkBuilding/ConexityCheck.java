package checkBuilding;

public class ConexityCheck {
	

}
